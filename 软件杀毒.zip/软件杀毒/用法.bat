@echo off
set start_time=%time%
echo [1/4] 正在扫描可疑进程...
wmic process get name,executablepath,processid | findstr /i "temp\ trojan backdoor malware keylogger" >nul && (echo  ⚠️ 发现可疑进程！) || echo  ✓ 无高危进程

echo [2/4] 检查异常网络连接...
netstat -ano | findstr ESTABLISHED | findstr /v ":80 :443 :53" >nul && (echo  ⚠️ 发现非常规端口通信！) || echo  ✓ 无异常连接

echo [3/4] 检查启动项...
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" | findstr /i "%TEMP%" >nul && (echo  ⚠️ 启动项含临时路径！) || echo  ✓ 启动项正常
reg query "HKLM\Software\Microsoft\Windows\CurrentVersion\Run" | findstr /i "%TEMP%" >nul && (echo  ⚠️ 系统启动项含临时路径！) || echo  ✓ 系统启动项正常

echo [4/4] 检查最近创建的可疑文件...
forfiles /p %TEMP% /m *.* /d +0 /c "cmd /c echo ⚠️ 检测到今日新建可疑文件: @file" >nul 2>nul
if not errorlevel 1 (echo  ⚠️ 检测到今日新建可疑文件！) else (echo  ✓ 临时目录清洁)

echo 完成检测 ^(耗时 %time:~0,8%^)
echo 注意：此为快速筛查，专业场景请用 Windows Defender 扫描