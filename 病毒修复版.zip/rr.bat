@echo off
chcp 65001 >nul
echo.
echo ================================================
echo    Python PATH 修复脚本
echo ================================================
echo.

REM 以管理员身份运行
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo 请以管理员身份运行此脚本!
    echo 右键点击 -> 以管理员身份运行
    pause
    exit /b 1
)

echo 正在查找Python安装目录...
set PYTHON_FOUND=0

REM 检查常见路径
for /f "tokens=*" %%I in ('dir /s /b "python.exe" 2^>nul ^| findstr /v "Windows"') do (
    set "PYTHON_PATH=%%~dpI"
    set PYTHON_FOUND=1
    goto :FOUND_PYTHON
)

:FOUND_PYTHON
if %PYTHON_FOUND% equ 0 (
    echo 未找到Python安装，请先安装Python
    pause
    exit /b 1
)

echo 找到Python安装目录: %PYTHON_PATH%
echo.

REM 添加到系统环境变量
echo 正在添加到系统PATH环境变量...
setx /M PATH "%PATH%;%PYTHON_PATH%"

echo.
echo 添加完成! 请重新打开CMD窗口测试
echo.
echo 测试命令:
echo python --version
echo pip --version
echo.
pause