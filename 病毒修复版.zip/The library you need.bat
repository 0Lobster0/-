@echo off
chcp 65001 >nul
echo.
echo ================================================
echo    Windows Python 环境自动配置脚本
echo ================================================
echo.

REM 检查管理员权限
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo 请以管理员身份运行此脚本!
    echo 右键点击 -> 以管理员身份运行
    pause
    exit /b 1
)

echo 步骤1: 正在检查Python是否已安装...
python --version >nul 2>&1
if %errorLevel% equ 0 (
    echo Python 已安装，跳过安装步骤
    goto :INSTALL_LIBRARIES
)

echo.
echo 步骤2: 下载并安装Python 3.9
echo.

REM 创建临时目录
set TEMP_DIR=%TEMP%\python_install
if not exist "%TEMP_DIR%" mkdir "%TEMP_DIR%"
cd /d "%TEMP_DIR%"

REM 下载Python 3.9安装包
echo 正在从清华镜像源下载Python...
powershell -Command "Invoke-WebRequest -Uri 'https://mirrors.tuna.tsinghua.edu.cn/python/3.9.13/python-3.9.13-amd64.exe' -OutFile 'python-installer.exe'"

if not exist "python-installer.exe" (
    echo 下载失败，请检查网络连接
    pause
    exit /b 1
)

echo 正在安装Python...
echo 请在弹出的安装窗口中勾选"Add Python to PATH"，然后点击Install Now
echo.
start /wait python-installer.exe

REM 等待安装完成
timeout /t 5 /nobreak >nul

:INSTALL_LIBRARIES
echo.
echo 步骤3: 配置Python镜像源并安装必要的库
echo.

REM 设置pip清华镜像源
echo 设置清华镜像源...
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
pip config set global.trusted-host pypi.tuna.tsinghua.edu.cn

echo.
echo 步骤4: 安装必要的Python库
echo.

REM 安装必要的库
pip install pygame==2.5.2
pip install opencv-python==4.9.0.80
pip install numpy==1.26.4
pip install pyinstaller==5.13.0
