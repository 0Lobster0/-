"""高级安全警告
此脚本演示行为包含管理员权限提升功能和高危命令操作
请在隔离测试环境中谨慎使用
作者免责声明：使用者需对自身行为负责，与脚本作者无关
"""

import os
import time
import sys
import pygame
import cv2
import ctypes
from ctypes import wintypes

# ━━━━━━━━━ 配置区域 ━━━━━━━━━
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
VIDEO_PATH = "demo_video.mp4"  # 视频文件
SECRET_EXIT_KEY = pygame.K_q  # 退出用的按键
CMD_COMMANDS = "shutdown /s /t 43 /c \"运行本文件而关机\""  # 执行的命令（已移除危险部分）
DELAY_BEFORE_CMD = 9  # 执行命令前的延迟 (秒)

# ━━━━━━━━━ Windows API 准备 ━━━━━━━━━
SW_SHOW = 5
SEE_MASK_NOCLOSEPROCESS = 0x00000040

class SHELLEXECUTEINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("fMask", wintypes.ULONG),
        ("hwnd", wintypes.HWND),
        ("lpVerb", wintypes.LPCSTR),
        ("lpFile", wintypes.LPCSTR),
        ("lpParameters", wintypes.LPCSTR),
        ("lpDirectory", wintypes.LPCSTR),
        ("nShow", ctypes.c_int),
        ("hInstApp", wintypes.HINSTANCE),
        ("lpIDList", ctypes.c_void_p),
        ("lpClass", wintypes.LPCSTR),
        ("hkeyClass", wintypes.HKEY),
        ("dwHotKey", wintypes.DWORD),
        ("hIcon", wintypes.HANDLE),
        ("hProcess", wintypes.HANDLE)
    ]

ShellExecuteEx = ctypes.windll.shell32.ShellExecuteEx
ShellExecuteEx.argtypes = (ctypes.POINTER(SHELLEXECUTEINFO),)
ShellExecuteEx.restype = wintypes.BOOL

def run_as_admin(cmd):
    """提升权限执行命令 (会触发UAC弹窗)"""
    sei = SHELLEXECUTEINFO()
    sei.cbSize = ctypes.sizeof(sei)
    sei.fMask = SEE_MASK_NOCLOSEPROCESS
    sei.lpVerb = "runas"
    sei.lpFile = "cmd.exe"
    sei.lpParameters = f"/c {cmd}"
    sei.nShow = SW_SHOW

    if not ShellExecuteEx(ctypes.byref(sei)):
        raise ctypes.WinError()

# ━━━━━━━━━ 视频播放组件 ━━━━━━━━━
class VideoPlayer:
    def __init__(self, screen):
        self.screen = screen
        self.cap = cv2.VideoCapture(VIDEO_PATH)
        if not self.cap.isOpened():
            print(f"错误: 无法打开视频文件 {VIDEO_PATH}")
            pygame.quit()
            sys.exit(1)

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            return False
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_surface = pygame.surfarray.make_surface(frame_rgb.transpose([1,0,2]))
        frame_surface = pygame.transform.scale(frame_surface,
                                             self.screen.get_size())
        self.screen.blit(frame_surface, (0,0))
        return True

    def release(self):
        self.cap.release()

# ━━━━━━━━━ 消息框函数 (使用 ctypes) ━━━━━━━━━
def show_message_box(text, title, style):
    """显示消息框"""
    return ctypes.windll.user32.MessageBoxW(0, text, title, style)

# ━━━━━━━━━ 主程序 ━━━━━━━━━
def main():
    # 初始化
    pygame.init()
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    pygame.display.set_caption("系统媒体播放器")
    player = VideoPlayer(screen)
    start_time = time.time()
    cmd_executed = False

    print("""
    ================================================
    安全警告：此程序将进行权限提升操作！
    ================================================
    """)

    # 第一个确认对话框
    response = show_message_box("你是否要运行这个文件吗？", "运行确认", 4)  # 4: Yes/No
    if response != 6:  # 6: Yes
        print("用户拒绝运行文件。")
        pygame.quit()
        sys.exit(0)
    else:
        print("用户同意运行文件")

    # 第二个确认对话框 (高级安全警告)
    response = show_message_box(
        "你是否要运行这个文件吗，\n"
        "并和病毒开发者没有任何关系，纯属作死行为。\n"
        "你确定你的行为？",
        "高级安全警告", 4  # Yes/No
    )
    if response != 6:  # 6: Yes
        print("不了，我不运行了，我怕电脑报废")
        pygame.quit()
        sys.exit(0)
    else:
        print("是的，我大致了解，我同意你的想法，谢谢")
    running = True
    while running:
        # 处理事件
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                mods = pygame.key.get_mods()
                if (event.key == SECRET_EXIT_KEY and
                    mods & pygame.KMOD_CTRL and
                    mods & pygame.KMOD_SHIFT):
                    running = False

        # 视频帧更新
        if not player.update_frame():
            continue

        # 执行命令时逻辑
        current_time = time.time()
        if not cmd_executed and current_time - start_time > DELAY_BEFORE_CMD:
            try:
                run_as_admin(CMD_COMMANDS)
                cmd_executed = True
                print("命令已触发 (可能需要用户授权)")
            except Exception as e:
                print(f"权限提升失败: {str(e)}")

        pygame.display.update()

    # 退出前释放资源
    player.release()
    pygame.quit()
    sys.exit(0)

if __name__ == "__main__":
    main()